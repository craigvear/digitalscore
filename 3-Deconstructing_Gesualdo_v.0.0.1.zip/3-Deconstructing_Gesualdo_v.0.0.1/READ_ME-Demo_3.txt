READ ME - Demo app 3 - Deconstructing Gesualdo

14 September 2018

This app has been tested on the following machines and OS, with no issues:
MacBook Pro - OSX 10.13.6
MacBook Pro - OSX 10.11.6
Windows 10 - version 1511


General problems and fix-its:
The images are not seen on the screen - check that the image folder is next to the app file and in the parent folder. Check that this contains the source materials as 5 folders. Check that there are image files in these folder. Check that the monitor that you are using is recognised by the computer OS, and is set as the primary screen. You may need to download the zip file again.

I want the score to show on a second screen/ projector - drag the demo screen window (e.g. demo2) into the desired monitor/projector screen. 

The screen occasionally goes blank - this is part of the random process. Use this creatively.



Further creative ideas
Expand to an octet and use a combination of instruments and voices.
