READ ME - Demo app 5 - Generative Notes

14 September 2018

This app has been tested on the following machines and OS, with no issues:
MacBook Pro - OSX 10.13.6
MacBook Pro - OSX 10.11.6
Windows 10 - version 1511


General problems and fix-its:
The notes start off out of range - yes this is part of the setup, and will happen each time.

I don't understand the stave system - treble and bass are normal. The additional staves above and below these are for clarity when using ledger lines. You should be able to read them as treble +8ve and bass -8ve.

The notes mutate beyond my range - you can actively transpose up or down an octave if this is the case.



Further creative ideas
Try exploring staggered starts, perhaps every 30 seconds.
Try experimenting with note length and dynamics. What happens if each event is short duration and quiet dynamic.
Have a play with spatial placement of the ensemble around, or within the audience.