READ ME - Demo app 8 - Waterfall Learning

14 September 2018

This app has been tested on the following machines and OS, with no issues:
MacBook Pro - OSX 10.13.6
MacBook Pro - OSX 10.11.6
Windows 10 - version 1511


General problems and fix-its:
The audio element of the score is not heard - the sound card is not setup correctly for your setup. Open audio help and ensure your computer is capable of supporting sound, has the infrastructure, and is setup correctly. You can use Youtube or the web to find a solution.

Audio Feedback - if the mic is positioned too close to the computer speakers you will get feedback. You can use this creatively (without damaging your hearing), or separate the mic and speakers by using external mic, headphones, speaker position or mixing.

The images are not seen on the screen - check that the image folder is next to the app file. Check that there is an image file in this folder. Check that the monitor that you are using is recognised by the computer OS, and is set as the primary screen. 

I want the score to show on a second screen/ projector - drag the demo screen window (e.g. demo2) into the desired monitor/projector screen. 

The screen occasionally goes blank - this is part of the random process. Use this creatively.



Further creative ideas
Try giving the blank score to several other musicians and ask them to conduct the same process using the same source material, but perhaps a different 1-minute audio extract. n 
