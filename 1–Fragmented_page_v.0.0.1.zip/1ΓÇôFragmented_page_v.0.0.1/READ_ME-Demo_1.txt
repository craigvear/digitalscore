READ ME - Demo app 1 - Fragmented Page

14 September 2018

This app has been tested on the following machines and OS, with no issues:
MacBook Pro - OSX 10.13.6
MacBook Pro - OSX 10.11.6
Windows 10 - version 1511


General problems and fix-its:
The images are not seen on the screen - check that the image folder is next to the app file and in the parent folder. Check that there is an image file in this folder. Check that the monitor that you are using is recognised by the computer OS, and is set as the primary screen. 

I want the score to show on a second screen/ projector - drag the demo screen window (e.g. demo2) into the desired monitor/projector screen. 

The screen occasionally goes blank - this is part of the random process. Use this creatively.



Further creative ideas
Make your own composite/ collage images from a variety of sources.