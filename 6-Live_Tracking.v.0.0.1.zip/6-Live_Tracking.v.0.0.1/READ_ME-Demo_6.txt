READ ME - Demo app 6 - Live Tracking

14 September 2018

This app has been tested on the following machines and OS, with no issues:
MacBook Pro - OSX 10.13.6
MacBook Pro - OSX 10.11.6
Windows 10 - version 1511


General problems and fix-its:
There is no live video image in the in-app monitor e.g. you can not see you - open Video help and choose correct device from drop down menu's.

Still not seeing me - this app requires you to download and install the cv.jit. Download and install in the correct folder the cv.jit package from Jean-Marc Pelletier. This app will not work without these additional files. All files and instructions can be found at https://jmpelletier.com/cvjit/  

The visual score is slow in its response - try adjusting the sensitivity on the app, or a different video camera (you will have to change settings in Video help).

The visual score is only showing a small portion of the score - the file may be too big. Try reducing it in size or DPI so that it is around 50-100 DPI or 15-30cms big, and no larger than 200kb in file size.

The audio element of the score is not heard - the sound card is not setup correctly for your setup. Open audio help and ensure your computer is capable of supporting sound, has the infrastructure, and is setup correctly. You can use Youtube or the web to find a solution.

Audio Feedback - if the mic is positioned too close to the computer speakers you will get feedback. You can use this creatively (without damaging your hearing), or separate the mic and speakers by using external mic, headphones, speaker position or mixing.

The images are not seen on the screen - check that the image folder is next to the app file and in the parent folder. Check that there is an image file in this folder. Check that the monitor that you are using is recognised by the computer OS, and is set as the primary screen. 

I want the score to show on a second screen/ projector - drag the demo screen window (e.g. demo2) into the desired monitor/projector screen. 



Further creative ideas
Make your own composite/ collage images from a variety of sources.
Try tracking a dancer with the camera while the musician plays the digital score - what sort of interaction does this create?